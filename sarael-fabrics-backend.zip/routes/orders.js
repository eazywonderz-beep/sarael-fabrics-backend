const express = require('express');
const db = require('../db');
const router = express.Router();

// create order (minimal)
router.post('/', async (req,res)=>{
  const {buyer_id, store_id, items, delivery_address, phone} = req.body;
  if(!buyer_id || !store_id || !items || !items.length) return res.status(400).json({error:'invalid order'});
  try{
    // compute total from items (expects unit_price included)
    const total = items.reduce((s,it)=>s + (it.unit_price * (it.quantity||1)), 0);
    const o = await db.query('INSERT INTO orders (buyer_id,store_id,status,total_amount,delivery_address,phone) VALUES ($1,$2,$3,$4,$5,$6) RETURNING *',
      [buyer_id,store_id,'received',total,delivery_address,phone]);
    const order = o.rows[0];
    for(const it of items){
      await db.query('INSERT INTO order_items (order_id,product_id,quantity,unit_price,length_requested) VALUES ($1,$2,$3,$4,$5)',
        [order.id,it.product_id,it.quantity||1,it.unit_price,it.length_requested||null]);
    }
    res.json({order});
  }catch(err){
    console.error(err);
    res.status(500).json({error:'failed to create order'});
  }
});

router.get('/:id', async (req,res)=>{
  try{
    const q = await db.query('SELECT * FROM orders WHERE id=$1', [req.params.id]);
    if(!q.rows.length) return res.status(404).json({error:'not found'});
    const order = q.rows[0];
    const items = await db.query('SELECT * FROM order_items WHERE order_id=$1', [order.id]);
    res.json({order,items:items.rows});
  }catch(err){
    console.error(err);
    res.status(500).json({error:'failed'});
  }
});

module.exports = router;
