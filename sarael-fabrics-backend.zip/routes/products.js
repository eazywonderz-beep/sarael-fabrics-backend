const express = require('express');
const db = require('../db');
const router = express.Router();

router.get('/', async (req,res)=>{
  try{
    const q = await db.query('SELECT * FROM products ORDER BY created_at DESC LIMIT 100');
    res.json({products:q.rows});
  }catch(err){
    console.error(err);
    res.status(500).json({error:'failed'});
  }
});

router.get('/:id', async (req,res)=>{
  try{
    const q = await db.query('SELECT * FROM products WHERE id=$1', [req.params.id]);
    if(!q.rows.length) return res.status(404).json({error:'not found'});
    res.json({product:q.rows[0]});
  }catch(err){
    console.error(err);
    res.status(500).json({error:'failed'});
  }
});

router.post('/', async (req,res)=>{
  // minimal create (no auth check in this starter)
  const {store_id,title,description,price_per_unit,unit,images,total_available_length,tags} = req.body;
  try{
    const q = await db.query(
      `INSERT INTO products (store_id,title,description,price_per_unit,unit,images,total_available_length,tags)
       VALUES ($1,$2,$3,$4,$5,$6,$7,$8) RETURNING *`,
      [store_id,title,description,price_per_unit,unit,JSON.stringify(images||[]),total_available_length,tags||[]]
    );
    res.json({product:q.rows[0]});
  }catch(err){
    console.error(err);
    res.status(500).json({error:'failed to create'});
  }
});

module.exports = router;
