const express = require('express');
const bcrypt = require('bcrypt');
const jwt = require('jsonwebtoken');
const db = require('../db');

module.exports = function(authLimiter){
  const router = express.Router();
  router.use(authLimiter);

  router.post('/register', async (req,res)=>{
    const {name, email, phone, password, role} = req.body;
    if(!phone || !password) return res.status(400).json({error:'phone and password required'});
    const hash = await bcrypt.hash(password, 10);
    try{
      const result = await db.query('INSERT INTO users (name,email,phone,password_hash,role) VALUES ($1,$2,$3,$4,$5) RETURNING id,name,email,phone,role', [name,email,phone,hash,role||'buyer']);
      const user = result.rows[0];
      res.json({user});
    }catch(err){
      console.error(err);
      res.status(500).json({error:'registration failed'});
    }
  });

  router.post('/login', async (req,res)=>{
    const {phone,password} = req.body;
    if(!phone||!password) return res.status(400).json({error:'phone and password required'});
    try{
      const q = await db.query('SELECT * FROM users WHERE phone=$1', [phone]);
      const user = q.rows[0];
      if(!user) return res.status(401).json({error:'invalid credentials'});
      const ok = await bcrypt.compare(password, user.password_hash);
      if(!ok) return res.status(401).json({error:'invalid credentials'});
      const token = jwt.sign({userId:user.id,role:user.role}, process.env.JWT_SECRET || 'secret', {expiresIn:'7d'});
      res.json({token});
    }catch(err){
      console.error(err);
      res.status(500).json({error:'login failed'});
    }
  });

  return router;
};
