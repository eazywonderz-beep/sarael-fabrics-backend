const express = require('express');
const AWS = require('aws-sdk');
const { v4: uuidv4 } = require('uuid');
const router = express.Router();

router.get('/presign', async (req,res)=>{
  const key = `uploads/${uuidv4()}.jpg`;
  const s3 = new AWS.S3({
    accessKeyId: process.env.AWS_ACCESS_KEY_ID,
    secretAccessKey: process.env.AWS_SECRET_ACCESS_KEY,
    region: process.env.S3_REGION,
    endpoint: process.env.S3_ENDPOINT || undefined,
    signatureVersion: 'v4'
  });
  const params = { Bucket: process.env.S3_BUCKET, Key: key, Expires: 300, ContentType: 'image/jpeg' };
  try{
    const url = await s3.getSignedUrlPromise('putObject', params);
    const publicUrl = `https://${process.env.S3_BUCKET}.s3.${process.env.S3_REGION}.amazonaws.com/${key}`;
    res.json({url,publicUrl});
  }catch(err){
    console.error(err);
    res.status(500).json({error:'failed to presign'});
  }
});

module.exports = router;
