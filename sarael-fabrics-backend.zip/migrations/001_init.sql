-- initial schema for sarael fabrics marketplace
CREATE TABLE IF NOT EXISTS users (
  id SERIAL PRIMARY KEY,
  name TEXT,
  phone TEXT UNIQUE,
  email TEXT UNIQUE,
  password_hash TEXT,
  role TEXT DEFAULT 'buyer',
  created_at TIMESTAMP DEFAULT now()
);

CREATE TABLE IF NOT EXISTS stores (
  id SERIAL PRIMARY KEY,
  owner_user_id INTEGER REFERENCES users(id),
  name TEXT,
  address TEXT,
  city TEXT,
  contact_phone TEXT,
  created_at TIMESTAMP DEFAULT now()
);

CREATE TABLE IF NOT EXISTS products (
  id SERIAL PRIMARY KEY,
  store_id INTEGER REFERENCES stores(id),
  title TEXT,
  description TEXT,
  price_per_unit NUMERIC,
  unit TEXT,
  images JSONB DEFAULT '[]'::jsonb,
  total_available_length NUMERIC,
  tags TEXT[],
  created_at TIMESTAMP DEFAULT now()
);

CREATE TABLE IF NOT EXISTS orders (
  id SERIAL PRIMARY KEY,
  buyer_id INTEGER REFERENCES users(id),
  store_id INTEGER REFERENCES stores(id),
  status TEXT DEFAULT 'received',
  total_amount NUMERIC,
  delivery_address TEXT,
  phone TEXT,
  created_at TIMESTAMP DEFAULT now()
);

CREATE TABLE IF NOT EXISTS order_items (
  id SERIAL PRIMARY KEY,
  order_id INTEGER REFERENCES orders(id),
  product_id INTEGER REFERENCES products(id),
  quantity INTEGER,
  unit_price NUMERIC,
  length_requested NUMERIC
);

CREATE TABLE IF NOT EXISTS deliveries (
  id SERIAL PRIMARY KEY,
  order_id INTEGER REFERENCES orders(id),
  driver_name TEXT,
  driver_phone TEXT,
  status TEXT DEFAULT 'pending',
  tracking_notes TEXT,
  created_at TIMESTAMP DEFAULT now()
);
