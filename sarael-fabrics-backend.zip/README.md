# Sarael Fabrics Marketplace — Backend

Minimal Node.js + Express backend for the Sarael Fabrics Marketplace.

## What's included
- Auth (JWT)
- Products endpoints
- Orders & delivery starter routes
- Presigned S3 upload helper
- Dockerfile + render.yaml for Render deployment
- SQL migration `migrations/001_init.sql`

## Quickstart (local)
1. Copy `.env.example` to `.env` and set `DATABASE_URL`.
2. Install: `npm install`
3. Run migrations: `npm run migrate` (requires `psql` and DATABASE_URL)
4. Start: `npm run dev`

## Deploy
This repo includes `Dockerfile` and `render.yaml` for quick Render deployment.
