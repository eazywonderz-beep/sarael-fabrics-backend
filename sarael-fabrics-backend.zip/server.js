require('dotenv').config();
const express = require('express');
const helmet = require('helmet');
const rateLimit = require('express-rate-limit');
const cors = require('cors');
const bodyParser = require('body-parser');

const app = express();
app.use(helmet());
app.use(cors());
app.use(bodyParser.json());

const PORT = process.env.PORT || 10000;

// simple rate limiter on auth routes
const authLimiter = rateLimit({ windowMs: 60*1000, max: 10 });

app.get('/health', (req, res) => res.json({ status: 'ok' }));

// basic route wiring
app.use('/api/auth', require('./routes/auth')(authLimiter));
app.use('/api/products', require('./routes/products'));
app.use('/api/orders', require('./routes/orders'));
app.use('/api/uploads', require('./routes/uploads'));

app.listen(PORT, () => {
  console.log(`Server running on port ${PORT}`);
});
